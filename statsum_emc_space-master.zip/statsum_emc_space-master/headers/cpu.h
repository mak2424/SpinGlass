#ifndef cpu_h
#define cpu_h

typedef unsigned long long int uint64_cu;
typedef unsigned int uint16_cu;

extern int const n;
extern bool spin_glass_read;
extern uint64_cu const length;
extern int const prime_n;

void J_read(int*, int*, const std::string&);
void J_write(const int *J_h, const int *J_v, int &sum_of_J, int sample_number);
void J_glass_generator(int*, int*, int);
void thread_init(int8_t*);
void out(const uint64_cu*, int, int, uint16_cu *prime_set, int, int, const std::string&);

#endif
